package PB;

import java.util.ArrayList;

public class Entry implements Comparable<Entry>{
	public static void main(String[] args) {
		Entry e = new Entry("A", "B", 23404603);
		e.equals("asdasd");
		e.equals(new ArrayList<Integer>());
		System.out.println(e);
	}
	
	private String firstName;
	private String lastName;
	private int number;
	
	public Entry()
	{
		this("", "");
	}
	
	public Entry(String firstName, String lastName)
	{
		this(firstName, lastName, 0);
	}
	
	public Entry(String firstName, String lastName, int number)
	{
		this.firstName = firstName ;
		this.lastName = lastName ;
		this.number = number;
	}
	
	@Override
	public String toString()
	{
		return firstName + " " + lastName + " " + number;
	}
	
	@Override
	public boolean equals(Object o)
	{
		if(o instanceof Entry)
		{
			Entry other = (Entry)o;
			
			if(this.compareTo(other) != 0)
				return false;
			else
				return number == other.number; 
		}
		else
			return false;
	}

	@Override
	public int compareTo(Entry o) {
		int firstNameCompare = firstName.compareTo(o.firstName);
		
		if(firstNameCompare == 0)
		{
			return lastName.compareTo(o.lastName);
		}
		else
			return firstNameCompare;
	}
}
