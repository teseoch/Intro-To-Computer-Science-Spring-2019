package PB;

import java.util.ArrayList;
import java.util.Collections;

public class PhoneBook {
	public static void main(String[] args) {
		PhoneBook pb = new PhoneBook();
		
		pb.add("a", "b", 2);
		pb.add("z", "a", 3);
		
		pb.add("a", "a", 12);
		pb.add("a", "a", 11);
		
		System.out.println(pb);
		
	}
	
	private ArrayList<Entry> entries;
	
	public PhoneBook()
	{
		entries = new ArrayList<>();
	}
	
	public void add(String firstName, String lastName, int number)
	{
		entries.add(new Entry(firstName, lastName, number));
		Collections.sort(entries);
	}
	
	@Override
	public String toString()
	{
		String s = "";
		
		for(Entry e : entries)
			s += e + "\n";
		
		return s;
	}
}
