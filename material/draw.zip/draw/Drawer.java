package draw;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public abstract class Drawer implements Comparable<Drawer> {
	public static void main(String[] args) throws FileNotFoundException {
		EPS ee = new EPS();
		Drawer d = new SVG();
		EPS e1 = (EPS)d;
		
		d.drawCircle(30, 30, 40);
		d.drawLine(0, 10, 10, 10);
		d.drawLine(15, 10, 25, 10);
		
		d.save("test.eps");
	}
	
	
	/*
	 * ArrayList<Interger>
	 */
	
	public int compareTo(Drawer d)
	{
		return content.compareTo(d.content);
	}
	
	protected String content;
	
	Drawer()
	{
		content = "";
	}
	
	public void save(String path) throws FileNotFoundException
	{
		File f = new File(path);
		
//		try {
			PrintWriter pr = new PrintWriter(f.getAbsolutePath());
			pr.print(content);
			pr.close();
//		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
	}
	
	public abstract void drawCircle(double x, double y, double r);
	public abstract void drawLine(double x1, double y1, double x2, double y2);
}
