package draw;

import java.io.FileNotFoundException;

public class SVG extends Drawer{

	SVG()
	{
		content += "<svg height=\"100\" width=\"100\">\n";	
	}
	
	@Override
	public void drawCircle(double x, double y, double r) {
		content += "<circle cx=\""+x+"\" cy=\""+y+"\" r=\""+r+"\" stroke=\"black\" stroke-width=\"3\" fill=\"black\" />\n";		
	}
	
	@Override
	public void drawLine(double x1, double y1, double x2, double y2)
	{
		content += "<line x1=\""+x1+"\" y1=\""+y1+"\" x2=\""+x2+"\" y2=\""+y2+"\" style=\"stroke:rgb(255,0,0);stroke-width:2\" />";
	}
	
	
	/*
	 * Compa
	 * try{
	 *  ...
	 *  }catch(Ex e)
	 *  {
	 *  } 
	 * 
	 */
	
	
	@Override
	public void save(String path) throws FileNotFoundException
	{
		content += "</svg>";
		
		super.save(path);
	}

}
