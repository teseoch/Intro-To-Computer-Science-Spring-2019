package draw;

public class EPS extends Drawer{
	public EPS()
	{
		content += "%!PS-Adobe-2.0 EPSF-2.0\n";
		content += "0 0 1 setrgbcolor\n";
	}

	@Override
	public void drawCircle(double x, double y, double r) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void drawLine(double x1, double y1, double x2, double y2) {
		// TODO Auto-generated method stub
		content += x1 + " " +  y1 + " moveto\n";
		content += x2 + " " +  y2 + " lineto\n";
		content += "stroke\n";
	}
	
}
