import processing.core.PApplet;

public class TestProcessing extends PApplet {
	int gridSize = 100;
	int cellSize = 5;


	int frameCounter;

	Grid grid;
	boolean pause;

	public static void main(String[] args) {
		PApplet.main("TestProcessing");
	}

	public void keyPressed() {
		if (key == ' ') {
			pause = !pause;
		}
	}



	public void settings() {
		pause = false;
		grid = new Grid(gridSize, 0.4);

		int windowSize = gridSize*cellSize;
		size(windowSize, windowSize);

		frameCounter = 0;
	}

	public void draw(){
		if(frameCounter <= 0) {
			if(!pause)
				grid.update();
			frameCounter=10;
		}

		--frameCounter;

		if (mousePressed) {
			int i = mouseX / cellSize;
			int j = mouseY / cellSize;

			grid.setAlive(i,j);
		}

		for(int i = 0; i < grid.size; ++i){
			for(int j = 0; j < grid.size; ++j){
				int x = cellSize*i;
				int y = cellSize*j;

				if(grid.isAlive(i,j))
				{
					fill(219, 8, 208);
					stroke(219, 8, 208);
				}
				else
				{
					fill(255, 255, 255);
					stroke(255, 255, 255);
				}


				rect(x, y, cellSize, cellSize);
			}
		}

	}
}