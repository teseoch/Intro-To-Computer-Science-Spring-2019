package tmp;

public class Professor {
	
}
