package tmp;

public class Student {

}
