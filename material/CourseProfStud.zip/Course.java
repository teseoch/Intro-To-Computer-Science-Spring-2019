package tmp;

public class Course {
	public static void main(String[] args) {
		Course[] courses = new Course[100];

		Student query = new Student();
		Course[] queryIsFollowing = new Course[100];

		int index = 0;
		for(Course c : courses)
		{
			for(int i = 0; i < c.nStudents; ++i)
			{
				if(c.students[i] == query)
				{
					queryIsFollowing[index] = c;
					index++;
					break;
				}
			}

		}
	}

	private Student[] students;
	private int nStudents;

	private Professor professor;

	Course()
	{
		students = new Student[60];
		nStudents  = 0;
	}
	
	public void addStudent(Student s)
	{
		students[nStudents] = s;
		nStudents++;
	}
}
